ENTERPRISE DATA RECONCILIATION PROJECT

Open:
Enterprise_Data_Reconciliation_Completed.ipynb

Supplied inputs:
- enterprise_database (1).db
- server_logs (1).txt
- daily_exchange_rates (1).csv

Generated outputs:
- df_final.csv
- active_users.csv
- extracted_data.csv
- exchange_rates_filled.csv
- monthly_revenue.csv
- top5_customers.csv
- CFO_Dashboard.png

Key results:
Raw logs: 100,000
ERROR logs removed: 5,098
Successful transactions: 94,902
Latest Active users: 14,183
Weekend rate gaps filled: 104
Final reconciled rows: 53,899
Total USD revenue: $148,274,622.90

Run the notebook from top to bottom in Jupyter Notebook or Google Colab.
